package com.example.dynamicfeature

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class AdditionalActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_additional)
    }
}