package com.example.core.utils

object Constant {
    const val emailUser = "eve.holt@reqres.in"
    const val passwordUser = "cityslicka"
    const val tokenRAWGamesApi = "85024d758cab40d787d3516f5b55a7b7"
}