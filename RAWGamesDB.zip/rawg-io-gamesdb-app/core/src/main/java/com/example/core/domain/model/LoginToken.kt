package com.example.core.domain.model

data class LoginToken (
    val token:String?
)